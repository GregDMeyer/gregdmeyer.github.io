
from argparse import ArgumentParser
from sys import stdin


def parse_args():
    parser = ArgumentParser()
    parser.add_argument('--only-start', '-i', type=int, default=1,
                        help='start index for "only" statements')
    return parser.parse_args()


def make_table(only_start=1):
    pebble_frames = []
    frame_idx = only_start
    for line in stdin:
        line = line.strip()

        if not line:
            continue

        for i, char in enumerate(line.strip()):
            if char in 'o●':
                char_type = 'pebble'
            elif char in '.○':
                char_type = 'ghost'
            elif char == ' ':
                char_type = 'empty'
            else:
                raise ValueError(f'unexpected char "{char}"')

            while len(pebble_frames) < i+1:
                pebble_frames.append({'empty': [], 'ghost': [], 'pebble': []})

            pebble_frames[i][char_type].append(frame_idx)

        frame_idx += 1

    rtn_lines = []
    rtn_lines.append(r"\begin{center}")
    rtn_lines.append(r"\def\arraystretch{2}")
    rtn_lines.append(r"\begin{tabularx}{0.8\linewidth}{"+'X'*len(pebble_frames)+"}")

    rtn_lines.append(
        r'$x$ & ' + ' & '.join('$x_{' + str(i) + '}$' for i in range(1, len(pebble_frames)-1)) + r' & $f(x)$ \\'
    )

    emoji_lines = []
    for frame_dict in pebble_frames:
        emojis = [
            ('pebble', r'\emoji{rock}'),
            ('ghost', r'\emoji{ghost}'),
        ]
        line = []
        for char_type, emoji in emojis:
            frame_list = condense_frames(frame_dict[char_type])
            if not frame_list:
                continue

            line.append(
                r'\only<' + frame_list + r'>{' + emoji + '}'
            )

        emoji_lines.append(''.join(line))

    rtn_lines.append(' &\n'.join(emoji_lines))
    rtn_lines.append(r'\\')

    rtn_lines.append(r'\end{tabularx}')
    rtn_lines.append(r'\end{center}')

    return '\n'.join(rtn_lines)


def condense_frames(frame_list):
    rtn = []
    start = None
    end = None

    for i in frame_list:
        if start is None or i - end > 1:
            rtn.append('')
            start = i
        end = i

        if start == end:
            cur = f'{start}'
        else:
            cur = f'{start}-{end}'

        rtn[-1] = cur

    return ','.join(rtn)


def main():
    args = parse_args()
    print(make_table(args.only_start))


if __name__ == '__main__':
    main()
